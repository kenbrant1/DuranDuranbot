DuranDuranbot is a teachable/trainable artificial intelligence music bot losely inspired by how the new wave band Duran Duran composes music. It uses machine learning to learn how to compose music that you prefer.



HOW TO RUN - 


Download and extract DuranDuranbot zip file to a location on your computer.

............

Inside the extracted folder, go to the "/program_files/training_data_folder" folder and extract the entire "ddbot_training_data.zip" file to that same folder it's in.

^DuranDuranbot will also not run unless this is done.

............

Then download and install SuperCollider, the IDE application which runs DuranDuranbot, from this website - https://supercollider.github.io/download

Once SuperCollider is installed, open the SuperCollider application, and from within SuperCollider, open the "duranduranbot_RUN_(open_to_run).scd" file.... and press "ctrl -Enter" or "cmd - Return" to run the application.

